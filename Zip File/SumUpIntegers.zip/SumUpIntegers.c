/* PROGRAM Sum Up integers from 1 to 100 numbers */
#include <stdlib.h>

int i;
int Sum = 0;

main() {
	for(i = 1; i<=100; i++)
		Sum += i;
	cout << "sum = " << sum;	
}
